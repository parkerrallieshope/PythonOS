from colorama import Fore, Style
print(f"{Fore.RED}This is some red text in a Python file written with PythonOS editor.{Style.RESET_ALL}")